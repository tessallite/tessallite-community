# Guidelines

- [design-guidelines](./docs/architecture/design-guidelines.md)
- [architecture_frontend-design](./docs/architecture/architecture_frontend-design.md)
