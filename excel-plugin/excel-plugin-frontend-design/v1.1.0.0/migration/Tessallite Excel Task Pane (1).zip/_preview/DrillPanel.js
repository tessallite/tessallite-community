var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.TessalliteExcel;
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // .design-sync/previews/DrillPanel.tsx
  var DrillPanel_exports = {};
  __export(DrillPanel_exports, {
    RevenueDetailRows: () => RevenueDetailRows
  });
  init_define_import_meta_env();

  // .design-sync/preview-api-stub.ts
  init_define_import_meta_env();

  // .design-sync/fixtures.ts
  init_define_import_meta_env();
  var noop = () => {
  };
  var measures = [
    { id: "m-revenue", name: "revenue", display_name: "Revenue", description: "Net invoiced revenue after returns and discounts.", default_agg: "sum", format: "#,##0", measure_type: "standard", display_folder: "Sales" },
    { id: "m-cost", name: "cost_of_sales", display_name: "Cost of Sales", description: "Landed cost of goods sold.", default_agg: "sum", format: "#,##0", measure_type: "standard", display_folder: "Sales" },
    { id: "m-margin", name: "gross_margin_pct", display_name: "Gross Margin %", description: "Revenue less cost of sales, as a share of revenue.", default_agg: "avg", format: "0.0%", measure_type: "calculated", display_folder: "Profitability" },
    { id: "m-orders", name: "order_count", display_name: "Order Count", description: "Distinct sales orders.", default_agg: "count_distinct", format: "#,##0", measure_type: "standard", display_folder: "Sales" },
    { id: "m-revenue-ly", name: "revenue_ly", display_name: "Revenue LY", description: "Revenue for the same period last year.", default_agg: "sum", format: "#,##0", measure_type: "variant", base_measure_id: "m-revenue", display_folder: "Sales" }
  ];
  var dimensions = [
    { id: "d-region", name: "region", display_name: "Region", description: "Sales region of the customer account.", data_type: "string", source_type: "dim" },
    { id: "d-product", name: "product_category", display_name: "Product Category", description: "Top level of the product catalogue.", data_type: "string", source_type: "dim" },
    { id: "d-channel", name: "sales_channel", display_name: "Sales Channel", data_type: "string", source_type: "dim" },
    { id: "d-month", name: "order_month", display_name: "Order Month", data_type: "date", source_type: "dim", is_time_dimension: true, calendar_type: "gregorian" },
    { id: "d-tier", name: "customer_tier", display_name: "Customer Tier", description: "Derived from trailing twelve month revenue.", data_type: "string", source_type: "calculated" }
  ];
  var hierarchies = [
    {
      id: "h-calendar",
      name: "calendar",
      display_name: "Calendar",
      type: "date_embedded",
      level_names: ["Year", "Quarter", "Month", "Day"],
      level_count: 4,
      calendar_type: "gregorian",
      levels: [
        { name: "Year", level_number: 1, time_unit: "year", dimensionName: "order_year" },
        { name: "Quarter", level_number: 2, time_unit: "quarter", dimensionName: "order_quarter" },
        { name: "Month", level_number: 3, time_unit: "month", dimensionName: "order_month" },
        { name: "Day", level_number: 4, time_unit: "day", dimensionName: "order_date" }
      ]
    },
    { id: "h-geo", name: "geography", display_name: "Geography", type: "explicit", level_names: ["Region", "Country", "City"], level_count: 3 },
    { id: "h-product", name: "product", display_name: "Product", type: "explicit", level_names: ["Category", "Sub-category", "Product"], level_count: 3 }
  ];
  var kpiBase = {
    display_folder: "Profitability",
    goal_measure_id: null,
    target_type: "static",
    status_expression: null,
    trend_expression: null,
    status_graphic: "traffic_light",
    trend_graphic: "standard_arrow",
    weight: null,
    parent_kpi_id: null,
    replacement_id: null,
    owner_user_id: null,
    updated_at: "2026-08-30T09:12:00Z",
    is_deployed: true
  };
  var kpis = [
    { ...kpiBase, id: "k-margin", name: "gross_margin_target", display_name: "Gross Margin Target", description: "Gross margin against the 42% annual target.", value_measure_id: "m-margin", target_value: 0.42, certification_status: "certified", kpi_type: "simple_measure", expression: null },
    { ...kpiBase, id: "k-growth", name: "revenue_growth", display_name: "Revenue Growth YoY", description: "Year on year revenue growth.", value_measure_id: null, target_value: 0.08, certification_status: "certified", kpi_type: "growth_rate", expression: "([Revenue] - [Revenue LY]) / [Revenue LY]" },
    { ...kpiBase, id: "k-orders", name: "orders_per_day", display_name: "Orders per Day", description: null, display_folder: "Sales", value_measure_id: "m-orders", target_value: 1200, certification_status: "pending", kpi_type: "simple_measure", expression: null, is_deployed: false }
  ];
  var namedSets = [
    { id: "ns-top10", name: "top_10_products", display_name: "Top 10 Products", description: "Ten products by trailing twelve month revenue.", display_folder: "Products", scope: 1, expression: "TopCount([Product].[Product].Members, 10, [Measures].[Revenue])", dimensions: "product", builder_definition: null, list_type: "top_n", certification_status: "certified", replacement_id: null, owner_user_id: null, updated_at: "2026-08-12T14:03:00Z" },
    { id: "ns-emea", name: "emea_countries", display_name: "EMEA Countries", description: "Countries reporting into the EMEA region.", display_folder: "Geography", scope: 1, expression: "{[Geography].[Country].&[GB], [Geography].[Country].&[DE], [Geography].[Country].&[FR]}", dimensions: "geography", builder_definition: null, list_type: "static", certification_status: "pending", replacement_id: null, owner_user_id: null, updated_at: "2026-08-20T08:40:00Z" }
  ];
  var glossary = [
    { id: "g-1", term: "Revenue", definition: "Net invoiced revenue after returns and discounts, recognised at ship date.", context_notes: "Excludes intercompany transfers.", source: "user", status: "approved", synonyms: ["Net sales", "Turnover"], sample_values: [] },
    { id: "g-2", term: "Gross Margin %", definition: "Revenue less cost of sales, divided by revenue.", source: "llm_approved", status: "approved", synonyms: ["GM%"], sample_values: [] },
    { id: "g-3", term: "Customer Tier", definition: "Gold, Silver or Bronze based on trailing twelve month revenue.", source: "llm", status: "pending", synonyms: [], sample_values: ["Gold", "Silver", "Bronze"] }
  ];
  var personas = [
    { id: "p-finance", name: "Finance Analyst", slug: "finance-analyst", description: "Full P&L measures, all regions.", audience: "Finance", included_measure_ids: ["m-revenue", "m-cost", "m-margin"], included_dimension_ids: ["d-region", "d-month"], included_hierarchy_ids: ["h-calendar"] },
    { id: "p-sales", name: "Regional Sales Manager", slug: "regional-sales", description: "Revenue and orders for the manager's own region.", audience: "Sales", included_measure_ids: ["m-revenue", "m-orders"], included_dimension_ids: ["d-region", "d-product", "d-channel"], included_hierarchy_ids: ["h-geo", "h-product"] }
  ];
  var resultRows = [
    { Region: "EMEA", "Product Category": "Hardware", Revenue: 4812300, "Gross Margin %": 0.41 },
    { Region: "EMEA", "Product Category": "Services", Revenue: 1205900, "Gross Margin %": 0.58 },
    { Region: "Americas", "Product Category": "Hardware", Revenue: 6390150, "Gross Margin %": 0.39 },
    { Region: "Americas", "Product Category": "Services", Revenue: 1988400, "Gross Margin %": 0.61 },
    { Region: "APAC", "Product Category": "Hardware", Revenue: 2144700, "Gross Margin %": 0.37 }
  ];
  var semanticQuery = {
    measures: ["revenue", "gross_margin_pct"],
    dimensions: ["region", "product_category"],
    timeDimensions: [{ dimension: "order_month", granularity: "month", dateRange: ["2026-01-01", "2026-06-30"] }],
    filters: [{ dimension: "sales_channel", operator: "equals", values: ["Direct"] }],
    order: { revenue: "desc" },
    limit: 500
  };
  var routeTrace = {
    route_type: "aggregate",
    reason: "Query grain (region, product_category, month) is covered by aggregate agg_sales_monthly.",
    aggregate_id: "agg_sales_monthly",
    pocket_id: null,
    rewritten_query: "SELECT region, product_category, SUM(revenue) AS revenue, AVG(gross_margin_pct) AS gross_margin_pct\nFROM agg_sales_monthly\nWHERE sales_channel = 'Direct' AND order_month BETWEEN '2026-01-01' AND '2026-06-30'\nGROUP BY region, product_category\nORDER BY revenue DESC\nLIMIT 500"
  };
  var drillOptions = [
    { hierarchy_id: "h-geo", hierarchy_name: "Geography", current_level_name: "Region", next_level_name: "Country" },
    { hierarchy_id: "h-product", hierarchy_name: "Product", current_level_name: "Category", next_level_name: "Sub-category" }
  ];

  // .design-sync/preview-api-stub.ts
  var model = { id: "model-sales", name: "Sales", slug: "sales", description: "Sales and profitability model", deployed: true };
  var project = { id: "proj-sales", name: "Commercial Analytics", slug: "commercial" };
  var kpiBatch = {
    results: [
      { kpi_id: "k-margin", value: 0.412, goal: 0.42, status: 0, trend: 1, status_label: "Below target", trend_label: "Improving", formatted_value: "41.2%", formatted_goal: "42.0%" },
      { kpi_id: "k-growth", value: 0.094, goal: 0.08, status: 1, trend: 1, status_label: "On target", trend_label: "Improving", formatted_value: "9.4%", formatted_goal: "8.0%" },
      { kpi_id: "k-orders", value: 1134, goal: 1200, status: -1, trend: 0, status_label: "Off target", trend_label: "Flat", formatted_value: "1,134", formatted_goal: "1,200" }
    ],
    evaluation_ms: 184
  };
  var drillRows = {
    columns: ["Order ID", "Order Date", "Customer", "Product", "Revenue"],
    rows: [
      { "Order ID": "SO-104211", "Order Date": "2026-06-02", Customer: "Northwind Traders", Product: "Rack Server R740", Revenue: 48200 },
      { "Order ID": "SO-104219", "Order Date": "2026-06-03", Customer: "Contoso Ltd", Product: "Storage Array S200", Revenue: 31750 },
      { "Order ID": "SO-104233", "Order Date": "2026-06-05", Customer: "Fabrikam Inc", Product: "Rack Server R740", Revenue: 48200 }
    ],
    page: { cursor: "", has_more: false },
    drill_mode: "detail",
    rows_returned: 3
  };
  var compat = { model_id: model.id, version_id: "v-12", generated_at: "2026-09-01T08:00:00Z", status: "compatible", measures: {}, multi_measure: null };
  var agentConfig = { configured: true, enabled: true, provider: "anthropic", model: "claude-sonnet-5", display_name: "Tessallite Analyst" };
  var routes = [
    [/\/kpis\/evaluate-batch/, () => kpiBatch],
    [/\/kpis\/[^/]+\/evaluate/, () => kpiBatch.results[0]],
    [/\/kpis(\?|$)/, () => kpis],
    [/\/named-sets(\?|$)/, () => namedSets],
    [/\/measures\/[^/]+\/drill-options/, () => ({ hierarchies: drillOptions })],
    [/\/drill-through-set/, () => ({ id: "dts-revenue", measure_id: "m-revenue", detail_columns: drillRows.columns.map((c, i) => ({ id: `col-${i}`, name: c, display_name: c, source_type: "dim" })), join_paths: [] })],
    [/\/measures\/[^/]+\/drill-through/, () => drillRows],
    [/\/measures(\?|$)/, () => measures],
    [/\/dimensions(\?|$)/, () => dimensions],
    [/\/hierarchies\/[^/?]+/, () => hierarchies[0]],
    [/\/hierarchies(\?|$)/, () => hierarchies],
    [/\/glossary(\?|$)/, () => glossary],
    [/\/personas(\?|$)/, () => personas],
    [/\/field-compatibility/, () => compat],
    [/\/agent(\/|\?|$)/, () => agentConfig],
    [/\/execute/, () => ({ query: semanticQuery, data: resultRows, route: routeTrace })],
    [/\/models\/[^/?]+$/, () => model],
    [/\/models(\?|$)/, () => [model]],
    [/\/projects(\?|$)/, () => [project]],
    [/\/health/, () => ({ status: "ok" })]
  ];
  function installPreviewApi() {
    if (typeof window === "undefined" || window.__tessPreviewApiInstalled) return;
    window.__tessPreviewApiInstalled = true;
    const g2 = globalThis;
    if (!g2.OfficeRuntime) {
      const mem = /* @__PURE__ */ new Map();
      g2.OfficeRuntime = { storage: {
        getItem: async (k) => /jwt|token/i.test(k) ? "preview.jwt.token" : mem.get(k) ?? null,
        setItem: async (k, v) => {
          mem.set(k, v);
        },
        removeItem: async (k) => {
          mem.delete(k);
        }
      } };
    }
    const realFetch = window.fetch.bind(window);
    window.fetch = async (input, init) => {
      const url = typeof input === "string" ? input : input instanceof URL ? input.href : input.url;
      const path = url.replace(/^https?:\/\/[^/]+/, "");
      if (path.includes("/api/v1/")) {
        for (const [rx, body] of routes) {
          const m = path.match(rx);
          if (m) return new Response(JSON.stringify(body(m)), { status: 200, headers: { "content-type": "application/json" } });
        }
        return new Response(JSON.stringify({ detail: `preview stub: no fixture for ${path}` }), { status: 404, headers: { "content-type": "application/json" } });
      }
      return realFetch(input, init);
    };
  }
  installPreviewApi();

  // ds-shim:ds
  var ds_exports = {};
  __export(ds_exports, {
    default: () => ds_default
  });
  init_define_import_meta_env();
  __reExport(ds_exports, __toESM(require_ds_raw()));
  var g = window.TessalliteExcel;
  var ds_default = "default" in g ? g.default : g;

  // .design-sync/previews/DrillPanel.tsx
  var import_jsx_runtime = __toESM(require_react_shim());
  function RevenueDetailRows() {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { style: { position: "relative", width: 340, height: 520 }, children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.DrillPanel, { open: true, onClose: noop, measureId: "m-revenue", measureName: "Revenue", context: { region: "EMEA", product_category: "Hardware" }, projectId: "proj-sales", modelId: "model-sales", onInsertSheet: noop }) });
  }
  return __toCommonJS(DrillPanel_exports);
})();
