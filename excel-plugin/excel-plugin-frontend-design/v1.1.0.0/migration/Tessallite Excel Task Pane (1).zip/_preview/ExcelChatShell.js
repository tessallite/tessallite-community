var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx3(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs2(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx3;
      module.exports.jsxs = jsxs2;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs2 : jsx3)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.TessalliteExcel;
    }
  });

  // .design-sync/previews/ExcelChatShell.tsx
  var ExcelChatShell_exports = {};
  __export(ExcelChatShell_exports, {
    AgentNotConfigured: () => AgentNotConfigured,
    AnsweredTurn: () => AnsweredTurn,
    EmptyConversation: () => EmptyConversation,
    FullTaskPane: () => FullTaskPane,
    LoadError: () => LoadError,
    Loading: () => Loading
  });
  init_define_import_meta_env();
  var import_react2 = __toESM(require_react_shim());

  // ds-shim:ds
  var ds_exports = {};
  __export(ds_exports, {
    default: () => ds_default
  });
  init_define_import_meta_env();
  __reExport(ds_exports, __toESM(require_ds_raw()));
  var g = window.TessalliteExcel;
  var ds_default = "default" in g ? g.default : g;

  // tessallite/excel-plugin/src/i18n/chatStrings.ts
  init_define_import_meta_env();

  // tessallite/excel-plugin/src/i18n/runtime.ts
  init_define_import_meta_env();
  var activeLocale = "en";
  var chatTranslations = {
    de: {
      "chat.chatAria": "Chat",
      "chat.emptyHint": "Stellen Sie eine Frage, um zu beginnen.",
      "chat.emptyTitle": "Noch keine Nachrichten",
      "chat.requestError": "Etwas ist schiefgelaufen. Bitte versuchen Sie es erneut.",
      "chat.retry": "Erneut versuchen",
      "chat.thinking": "Denkt nach...",
      "composer.placeholder": "Stellen Sie eine Frage zu Ihren Daten...",
      "composer.messageInputAria": "Nachrichteneingabe",
      "composer.sendAria": "Nachricht senden",
      "turn.errorFallback": "Beim Erstellen dieser Antwort ist ein Fehler aufgetreten.",
      "turn.refused": "Diese Anfrage wurde abgelehnt",
      "badges.rows": "{{count}} Zeilen",
      "badges.seconds": "{{seconds}} s",
      "chart.truncated": "Zeige die ersten {{count}} von {{total}} Zeilen",
      "steps.header": "Schritte ({{n}})",
      "steps.step": "Schritt {{n}}",
      // R2-B04: these 7 keys were added to chatStrings.ts's English fallback
      // only, not here, despite the L0 commit claiming "en + de/fr" — an
      // external cross-family review caught the gap. Translations match
      // tessallite/frontend's de locale for the same keys.
      "chart.measuresDimension": "Kennzahlen",
      "chart.rowLabel": "Zeile {{n}}",
      "chart.rowsDimension": "Zeilen",
      "chart.valueSeriesName": "Wert",
      "chat.scrollToBottomAria": "Nach unten scrollen",
      "queryBlock.copied": "Kopiert",
      "queryBlock.copy": "Kopieren"
    },
    fr: {
      "chat.chatAria": "Chat",
      "chat.emptyHint": "Posez une question pour commencer.",
      "chat.emptyTitle": "Aucun message pour le moment",
      "chat.requestError": "Un problème est survenu. Réessayez.",
      "chat.retry": "Réessayer",
      "chat.thinking": "Réflexion...",
      "composer.placeholder": "Posez une question sur vos données...",
      "composer.messageInputAria": "Saisie du message",
      "composer.sendAria": "Envoyer le message",
      "turn.errorFallback": "Une erreur est survenue pendant la génération de cette réponse.",
      "turn.refused": "Cette demande a été refusée",
      "badges.rows": "{{count}} lignes",
      "badges.seconds": "{{seconds}} s",
      "chart.truncated": "Affichage des {{count}} premières lignes sur {{total}}",
      "steps.header": "Étapes ({{n}})",
      "steps.step": "Étape {{n}}",
      // R2-B04: see the matching comment in the `de` block above.
      "chart.measuresDimension": "Mesures",
      "chart.rowLabel": "Ligne {{n}}",
      "chart.rowsDimension": "Lignes",
      "chart.valueSeriesName": "Valeur",
      "chat.scrollToBottomAria": "Défiler vers le bas",
      "queryBlock.copied": "Copié",
      "queryBlock.copy": "Copier"
    }
  };
  function interpolate(template, params) {
    if (!params) return template;
    let rendered = template;
    for (const [key, value] of Object.entries(params)) {
      rendered = rendered.split(`{{${key}}}`).join(String(value));
    }
    return rendered;
  }
  function translateChat(key, english, params) {
    const template = chatTranslations[activeLocale]?.[key] ?? english;
    return interpolate(template, params);
  }

  // tessallite/excel-plugin/src/i18n/chatStrings.ts
  var STRINGS = {
    // Chat canvas
    "chat.chatAria": "Chat panel",
    "chat.collapseThought": "Collapse thought stream",
    "chat.conversationAria": "Conversation messages",
    "chat.createConversationFailed": "Could not create conversation. Please try again.",
    "chat.connectionError": "Connection error. Please try again.",
    "chat.emptyHint": "Ask a question to get started.",
    "chat.emptyTitle": "No messages yet",
    "chat.expandThought": "Expand thought stream",
    "chat.requestError": "Something went wrong. Please try again.",
    "chat.retry": "Retry",
    "chat.retryAria": "Retry sending message",
    "chat.scopeMismatch": "That conversation was created under a different model or persona. Starting a new conversation with your current settings.",
    "chat.scrollToBottomAria": "Scroll to bottom",
    "chat.thinking": "Thinking...",
    "chat.thinkingAria": "Agent is thinking",
    "chat.thoughtStreaming": "Thought stream is available",
    "chat.titleSaveFailed": "Could not save conversation title.",
    // Stream errors (Bug-8370) — typed StreamErrorCode -> friendly message
    "stream.error.httpError": "The server rejected the request. Please try again.",
    "stream.error.timeout": "The response took too long and timed out. Please try again.",
    "stream.error.unexpectedEnd": "The response ended unexpectedly. Please check the conversation or try again.",
    "stream.error.connectionLost": "Connection was lost after the response started. Please check the conversation before resending.",
    "stream.error.networkError": "A connection problem prevented the response from completing. Please try again.",
    // Composer
    "composer.placeholder": "Ask a question about your data...",
    // DataTableBlock (Bug-7546: these keys were missing, causing raw key display)
    "dataTable.copied": "Copied",
    "dataTable.copy": "Copy table as TSV",
    "dataTable.exceedsLimit": "Results exceed the display limit ({{count}} rows). Try refining your query.",
    "dataTable.no": "No",
    "dataTable.yes": "Yes",
    // QueryBlock (Bug-7549)
    "queryBlock.copied": "Copied",
    "queryBlock.copy": "Copy",
    "composer.messageInputAria": "Message input",
    "composer.sendAria": "Send message",
    "composer.stopAria": "Stop generating",
    // Turn
    "turn.blockedQuality": "This response was blocked by the quality review",
    "turn.blockedSafeDetail": "The original answer is hidden because it did not pass review. You can rephrase the question, retry with the review note, or inspect safe trace details if they are enabled.",
    "turn.calcStepDescription": "Step",
    "turn.calcStepValue": "Value",
    "turn.diagnostics": "Diagnostics",
    "turn.errorFallback": "An error occurred while generating this response.",
    "turn.hideData": "Hide data",
    "turn.maximizeVisual": "Maximize chart",
    "turn.physicalQuery": "Physical query",
    "turn.refused": "This request was refused",
    "turn.rawRecordsNotSupported": "Raw transaction records are not supported by the aggregate query tools. Ask for a count, total, or grouped summary instead.",
    "turn.refusedSafeDetail": "The request was refused by the configured guardrails.",
    "turn.rephrase": "Rephrase",
    "turn.rephraseHint": "Try rephrasing your question.",
    "turn.semanticQuery": "Semantic query",
    "turn.supportingDetails": "Supporting details",
    "turn.thinking": "Thinking",
    "turn.viewTrace": "View trace",
    "turn.visual": "Visual",
    // Badges
    "badges.completed": "Completed",
    "badges.blocked": "Blocked",
    // Citations
    "citations.label": "Citations",
    "citations.source": "Source",
    "citations.measure": "Measure",
    "citations.dimension": "Dimension",
    "citations.provenance.title": "How this number was calculated",
    "citations.provenance.definitionLabel": "Definition",
    "citations.provenance.noDefinition": "No definition recorded for this field.",
    "citations.provenance.valueLabel": "Value",
    "citations.provenance.filterGrainLabel": "Filters and grouping applied",
    "citations.provenance.noFilterGrain": "No filters. This is the unfiltered total.",
    // Chart
    "chart.ariaDescription": "Chart of the query result.",
    "chart.distribution": "Distribution",
    "chart.exportTitle": "Save",
    "chart.measuresDimension": "Measures",
    "chart.result": "Result",
    "chart.rowsDimension": "Rows",
    "chart.trend": "Trend",
    "chart.valueSeriesName": "Value",
    // Judge
    "judge.evaluating": "Reviewing answer...",
    "judge.approves": "Review passed",
    "judge.concerned": "Review warning",
    "judge.didNotApprove": "Review blocked this answer",
    "judge.unavailable": "Review unavailable",
    "judge.sendBackToCorrect": "Retry with review note",
    "judge.correctPreviousNoReason": "Please correct the previous answer and answer again without using the blocked wording.",
    "judge.correctPreviousWithReason": "Please correct the previous answer using this review note:",
    // Model picker
    "modelPicker.tooltip": "Select model",
    "modelPicker.ariaLabel": "Select model",
    "modelPicker.projectDefault": "Project default",
    "modelPicker.projectDefaultHint": "Uses the project's configured primary model",
    "modelPicker.sectionLabel": "Available models",
    "modelPicker.none": "No models available",
    "modelPicker.updateFailed": "Could not update model selection.",
    // Rendered output
    "renderedOutput.closeAria": "Close",
    "renderedOutput.dialogTitle": "Output",
    "renderedOutput.iframeTitle": "Rendered answer output",
    "renderedOutput.openLargerAria": "Open larger view",
    "renderedOutput.unsafeFallback": "The visual output could not be displayed safely.",
    // Trace
    "trace.answerTrace": "Answer trace",
    "trace.howIThought": "How I thought about this",
    "trace.semanticQuery": "Semantic query",
    "trace.physicalQuery": "Physical query",
    // Parameterized entries — plain `{{param}}` interpolation templates, mirroring
    // the canonical shared-chat.json verbatim. `translateChat` substitutes the
    // params (as-is, no re-formatting — see the file header). The param NAMES here
    // are the ones the shared-ui producers pass to `t()` (e.g. InlineStepCard
    // passes `{ n }`, MetadataBadges passes `{ count }`).
    "badges.judge": "Judge: {{verdict}}",
    "badges.route": "Route: {{route}}",
    "badges.rows": "{{count}} rows",
    "badges.seconds": "{{seconds}}s",
    "chart.ariaLabel": "{{title}} chart. Expand the data table below for the underlying values.",
    "chart.rowLabel": "Row {{n}}",
    "chart.truncated": "Showing first {{count}} of {{total}} rows",
    "composer.tooLong": "Message exceeds {{max}} character limit",
    "steps.header": "Steps ({{n}})",
    "steps.step": "Step {{n}}",
    "steps.rows": "{{count}} rows",
    "trace.latencyMs": "{{ms}}ms",
    "trace.routeWithValue": "Route: {{route}}",
    "trace.physicalQueryRoute": "Physical query ({{route}})",
    "trace.toolWithValue": "Tool: {{tool}}",
    "turn.calculationSteps": "Calculation steps ({{count}})",
    "turn.closeVisual": "Close",
    "turn.calcStepFormula": "Formula: {{formula}}",
    "turn.showData": "Show data ({{count}} rows)",
    "turn.answeredBy": "Answered by {{provider}}"
  };
  var CHAT_STRING_KEYS = new Set(Object.keys(STRINGS));
  function chatT(key, params) {
    const english = STRINGS[key] ?? key;
    return translateChat(key, english, params);
  }

  // .design-sync/fixtures.ts
  init_define_import_meta_env();
  var noop = () => {
  };
  var kpiBase = {
    display_folder: "Profitability",
    goal_measure_id: null,
    target_type: "static",
    status_expression: null,
    trend_expression: null,
    status_graphic: "traffic_light",
    trend_graphic: "standard_arrow",
    weight: null,
    parent_kpi_id: null,
    replacement_id: null,
    owner_user_id: null,
    updated_at: "2026-08-30T09:12:00Z",
    is_deployed: true
  };
  var kpis = [
    { ...kpiBase, id: "k-margin", name: "gross_margin_target", display_name: "Gross Margin Target", description: "Gross margin against the 42% annual target.", value_measure_id: "m-margin", target_value: 0.42, certification_status: "certified", kpi_type: "simple_measure", expression: null },
    { ...kpiBase, id: "k-growth", name: "revenue_growth", display_name: "Revenue Growth YoY", description: "Year on year revenue growth.", value_measure_id: null, target_value: 0.08, certification_status: "certified", kpi_type: "growth_rate", expression: "([Revenue] - [Revenue LY]) / [Revenue LY]" },
    { ...kpiBase, id: "k-orders", name: "orders_per_day", display_name: "Orders per Day", description: null, display_folder: "Sales", value_measure_id: "m-orders", target_value: 1200, certification_status: "pending", kpi_type: "simple_measure", expression: null, is_deployed: false }
  ];
  var personas = [
    { id: "p-finance", name: "Finance Analyst", slug: "finance-analyst", description: "Full P&L measures, all regions.", audience: "Finance", included_measure_ids: ["m-revenue", "m-cost", "m-margin"], included_dimension_ids: ["d-region", "d-month"], included_hierarchy_ids: ["h-calendar"] },
    { id: "p-sales", name: "Regional Sales Manager", slug: "regional-sales", description: "Revenue and orders for the manager's own region.", audience: "Sales", included_measure_ids: ["m-revenue", "m-orders"], included_dimension_ids: ["d-region", "d-product", "d-channel"], included_hierarchy_ids: ["h-geo", "h-product"] }
  ];
  var resultRows = [
    { Region: "EMEA", "Product Category": "Hardware", Revenue: 4812300, "Gross Margin %": 0.41 },
    { Region: "EMEA", "Product Category": "Services", Revenue: 1205900, "Gross Margin %": 0.58 },
    { Region: "Americas", "Product Category": "Hardware", Revenue: 6390150, "Gross Margin %": 0.39 },
    { Region: "Americas", "Product Category": "Services", Revenue: 1988400, "Gross Margin %": 0.61 },
    { Region: "APAC", "Product Category": "Hardware", Revenue: 2144700, "Gross Margin %": 0.37 }
  ];
  var semanticQuery = {
    measures: ["revenue", "gross_margin_pct"],
    dimensions: ["region", "product_category"],
    timeDimensions: [{ dimension: "order_month", granularity: "month", dateRange: ["2026-01-01", "2026-06-30"] }],
    filters: [{ dimension: "sales_channel", operator: "equals", values: ["Direct"] }],
    order: { revenue: "desc" },
    limit: 500
  };
  var routeTrace = {
    route_type: "aggregate",
    reason: "Query grain (region, product_category, month) is covered by aggregate agg_sales_monthly.",
    aggregate_id: "agg_sales_monthly",
    pocket_id: null,
    rewritten_query: "SELECT region, product_category, SUM(revenue) AS revenue, AVG(gross_margin_pct) AS gross_margin_pct\nFROM agg_sales_monthly\nWHERE sales_channel = 'Direct' AND order_month BETWEEN '2026-01-01' AND '2026-06-30'\nGROUP BY region, product_category\nORDER BY revenue DESC\nLIMIT 500"
  };

  // .design-sync/task-pane-frame.tsx
  init_define_import_meta_env();
  var import_react = __toESM(require_react_shim());
  var import_jsx_runtime = __toESM(require_react_shim());
  var profiles = [
    { id: "prof-1", name: "Acme production", serverUrl: "https://tessallite.acme.example", tenantId: "acme", email: "j.doe@acme.example", createdAt: "2026-05-02T09:00:00Z" },
    { id: "prof-2", name: "Acme staging", serverUrl: "https://staging.tessallite.acme.example", tenantId: "acme", email: "j.doe@acme.example", createdAt: "2026-07-14T16:20:00Z" }
  ];
  var projects = [{ id: "proj-sales", name: "Commercial Analytics" }, { id: "proj-ops", name: "Operations" }];
  function TaskPaneFrame({ mode, children, offline = false, height = 760 }) {
    const paneHeight = globalThis.__tessPaneHeight ?? height;
    const [tab, setTab] = (0, import_react.useState)(mode);
    const [projectId, setProjectId] = (0, import_react.useState)("proj-sales");
    const [personaId, setPersonaId] = (0, import_react.useState)("p-finance");
    return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { style: { width: 340, minWidth: 320, height: paneHeight, display: "flex", flexDirection: "column", overflow: "hidden", background: ds_exports.tokens.colorWhite }, children: [
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.AppHeader, { profiles, activeProfile: profiles[0], onOpenDrill: noop, onOpenGlossary: noop, onOpenDiagnostics: noop, onSwitchProfile: noop, onRemoveProfile: noop, onLogout: noop }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.ProjectBar, { projects, projectId, onProjectChange: setProjectId }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.ModeTabs, { mode: tab, onModeChange: setTab, askLabel: "Ask Tessallite" }),
      offline && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.OfflineBanner, { onRetry: noop }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { role: "tabpanel", id: `tabpanel-${mode}`, style: { flex: 1, minHeight: 0, overflow: "auto", position: "relative", display: "flex", flexDirection: "column" }, children }),
      /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.AppFooter, { email: "j.doe@acme.example", personas, activePersonaId: personaId, onPersonaSelect: (p) => setPersonaId(p?.id ?? null), connected: !offline, reconnecting: offline })
    ] });
  }

  // .design-sync/previews/ExcelChatShell.tsx
  var import_jsx_runtime2 = __toESM(require_react_shim());
  var conversation = { id: "conv-1", project_id: "proj-sales", title: "Revenue by region", pinned_at: null, started_at: "2026-09-04T09:00:00Z", last_active_at: "2026-09-04T09:02:00Z", deleted_at: null, persona_id: "p-finance", pinned_model_id: "model-sales" };
  var turn = {
    id: "turn-1",
    conversation_id: "conv-1",
    turn_index: 0,
    user_message: "What was revenue by region and product category in the first half, direct channel only?",
    answer_text: "Direct-channel revenue for H1 2026 was **16.5M**. The Americas led with 8.4M (Hardware 6.4M, Services 2.0M), followed by EMEA at 6.0M and APAC at 2.1M. Services carry the strongest gross margin at 58-61%.",
    status: "ok",
    latency_ms: 2140,
    thought_summary: 'Resolved "first half" to Jan-Jun 2026 and "direct channel" to Sales Channel = Direct; grouped Revenue and Gross Margin % by Region and Product Category.',
    semantic_query: semanticQuery,
    routed_sql: routeTrace.rewritten_query,
    route: "aggregate",
    citations: [
      { kind: "measure", id: "m-revenue", name: "revenue", display_name: "Revenue", value: 16541450, definition: "Net invoiced revenue after returns and discounts.", route_type: "aggregate", filter_grain: "Sales Channel = Direct; by Region, Product Category" },
      { kind: "dimension", id: "d-region", name: "region", display_name: "Region", value: null, definition: "Sales region of the customer account.", route_type: "aggregate", filter_grain: null }
    ],
    user_feedback: null,
    judge_verdict: "pass",
    judge_reasoning: "Figures match the query result; time and channel filters applied as asked.",
    judge_metrics: { faithfulness: 0.98, completeness: 0.95 },
    guardrail_actions: null,
    usage_input_tokens: 1820,
    usage_output_tokens: 240,
    rendered_output: null,
    llm_plan: null,
    query_result_rows: resultRows.length,
    query_result_sample: resultRows,
    calculation_steps: null,
    chart_type: "grouped_bar",
    provider: "anthropic",
    judge_pending: false
  };
  var config = { enabled: true, show_thought_process: true, show_semantic_query: true, show_physical_query: true, feedback_enabled: true, display_name: "Tessallite Analyst", include_data_table: true, chart_renderer: "echarts", chart_type_selector: "auto" };
  function adapter(turns) {
    return {
      getConversations: async () => [conversation],
      createConversation: async () => conversation,
      getConversation: async () => conversation,
      updateConversation: async () => conversation,
      deleteConversation: async () => {
      },
      getTurns: async () => turns,
      streamMessageRaw: async () => new Response("", { status: 200 }),
      submitFeedback: async () => {
      },
      getSelectableModels: async () => [{ id: "model-sales", name: "Sales" }],
      getPersonas: async () => [],
      getConfig: async () => config
    };
  }
  function Shell(props) {
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)("div", { style: { width: 340, height: 640, display: "flex", flexDirection: "column" }, children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      ds_exports.ExcelChatShell,
      {
        adapter: adapter([turn]),
        t: chatT,
        projectId: "proj-sales",
        config,
        activeModelId: "model-sales",
        activePersonaId: "p-finance",
        agentConfigured: true,
        providerModel: "claude-sonnet-5",
        onInsertTable: noop,
        onInsertChart: noop,
        onInsertLocalPivot: noop,
        onFeedback: noop,
        ...props
      }
    ) });
  }
  function AnsweredTurn() {
    const setActiveConversation = (0, ds_exports.useConversationStore)((s) => s.setActiveConversation);
    (0, import_react2.useEffect)(() => {
      setActiveConversation("conv-1");
    }, [setActiveConversation]);
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Shell, {});
  }
  function EmptyConversation() {
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Shell, { adapter: adapter([]) });
  }
  function AgentNotConfigured() {
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Shell, { agentConfigured: false });
  }
  function Loading() {
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Shell, { loading: true });
  }
  function LoadError() {
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(Shell, { error: "The agent service did not respond. Check the server URL in Settings." });
  }
  function FullTaskPane() {
    const setActiveConversation = (0, ds_exports.useConversationStore)((s) => s.setActiveConversation);
    (0, import_react2.useEffect)(() => {
      setActiveConversation("conv-1");
    }, [setActiveConversation]);
    return /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(TaskPaneFrame, { mode: "ask", children: /* @__PURE__ */ (0, import_jsx_runtime2.jsx)(
      ds_exports.ExcelChatShell,
      {
        adapter: adapter([turn]),
        t: chatT,
        projectId: "proj-sales",
        config,
        activeModelId: "model-sales",
        activePersonaId: "p-finance",
        agentConfigured: true,
        providerModel: "claude-sonnet-5",
        onInsertTable: noop,
        onInsertChart: noop,
        onInsertLocalPivot: noop,
        onFeedback: noop
      }
    ) });
  }
  return __toCommonJS(ExcelChatShell_exports);
})();
