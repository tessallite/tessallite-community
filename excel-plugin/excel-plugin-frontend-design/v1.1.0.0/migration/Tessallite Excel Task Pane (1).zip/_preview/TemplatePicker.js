var __dsPreview = (() => {
  var __create = Object.create;
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __getProtoOf = Object.getPrototypeOf;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __esm = (fn, res, err) => function __init() {
    if (err) throw err[0];
    try {
      return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
    } catch (e) {
      throw err = [e], e;
    }
  };
  var __commonJS = (cb, mod) => function __require() {
    try {
      return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
    } catch (e) {
      throw mod = 0, e;
    }
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __reExport = (target, mod, secondTarget) => (__copyProps(target, mod, "default"), secondTarget && __copyProps(secondTarget, mod, "default"));
  var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
    // If the importer is in node compatibility mode or this is not an ESM
    // file that has been converted to a CommonJS file using a Babel-
    // compatible transform (i.e. "__esModule" has not been set), then set
    // "default" to the CommonJS "module.exports" for node compatibility.
    isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
    mod
  ));
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // <define:import.meta.env>
  var init_define_import_meta_env = __esm({
    "<define:import.meta.env>"() {
    }
  });

  // ds-raw:__ds_raw__
  var require_ds_raw = __commonJS({
    "ds-raw:__ds_raw__"(exports, module) {
      init_define_import_meta_env();
      module.exports = window.TessalliteExcel;
    }
  });

  // shim:react-shim
  var require_react_shim = __commonJS({
    "shim:react-shim"(exports, module) {
      init_define_import_meta_env();
      var R = window.React;
      function np(p, k) {
        var o = {};
        for (var x in p) if (x !== "children") o[x] = p[x];
        if (k !== void 0) o.key = k;
        return o;
      }
      function jsx2(t, p, k) {
        var c = p && p.children;
        return c === void 0 ? R.createElement(t, np(p, k)) : R.createElement(t, np(p, k), c);
      }
      function jsxs(t, p, k) {
        return R.createElement.apply(R, [t, np(p, k)].concat(p.children));
      }
      module.exports = R;
      module.exports.jsx = jsx2;
      module.exports.jsxs = jsxs;
      module.exports.jsxDEV = function(t, p, k, s) {
        return (s ? jsxs : jsx2)(t, p, k);
      };
      module.exports.Fragment = R.Fragment;
    }
  });

  // .design-sync/previews/TemplatePicker.tsx
  var TemplatePicker_exports = {};
  __export(TemplatePicker_exports, {
    AllApplicable: () => AllApplicable,
    MeasuresOnly: () => MeasuresOnly
  });
  init_define_import_meta_env();

  // ds-shim:ds
  var ds_exports = {};
  __export(ds_exports, {
    default: () => ds_default
  });
  init_define_import_meta_env();
  __reExport(ds_exports, __toESM(require_ds_raw()));
  var g = window.TessalliteExcel;
  var ds_default = "default" in g ? g.default : g;

  // .design-sync/fixtures.ts
  init_define_import_meta_env();
  var noop = () => {
  };
  var kpiBase = {
    display_folder: "Profitability",
    goal_measure_id: null,
    target_type: "static",
    status_expression: null,
    trend_expression: null,
    status_graphic: "traffic_light",
    trend_graphic: "standard_arrow",
    weight: null,
    parent_kpi_id: null,
    replacement_id: null,
    owner_user_id: null,
    updated_at: "2026-08-30T09:12:00Z",
    is_deployed: true
  };
  var kpis = [
    { ...kpiBase, id: "k-margin", name: "gross_margin_target", display_name: "Gross Margin Target", description: "Gross margin against the 42% annual target.", value_measure_id: "m-margin", target_value: 0.42, certification_status: "certified", kpi_type: "simple_measure", expression: null },
    { ...kpiBase, id: "k-growth", name: "revenue_growth", display_name: "Revenue Growth YoY", description: "Year on year revenue growth.", value_measure_id: null, target_value: 0.08, certification_status: "certified", kpi_type: "growth_rate", expression: "([Revenue] - [Revenue LY]) / [Revenue LY]" },
    { ...kpiBase, id: "k-orders", name: "orders_per_day", display_name: "Orders per Day", description: null, display_folder: "Sales", value_measure_id: "m-orders", target_value: 1200, certification_status: "pending", kpi_type: "simple_measure", expression: null, is_deployed: false }
  ];

  // .design-sync/previews/TemplatePicker.tsx
  var import_jsx_runtime = __toESM(require_react_shim());
  function AllApplicable() {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.TemplatePicker, { open: true, onClose: noop, onSelect: noop, measureCount: 2, hasTimeDimension: true, hasCategoricalDimension: true });
  }
  function MeasuresOnly() {
    return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ds_exports.TemplatePicker, { open: true, onClose: noop, onSelect: noop, measureCount: 1, hasTimeDimension: false, hasCategoricalDimension: false });
  }
  return __toCommonJS(TemplatePicker_exports);
})();
