# Tessallite Excel task pane - how to build with these components

These are the real React components of the Tessallite Excel add-in task pane
(`window.TessalliteExcel.*`). They follow the Microsoft Office Add-in design
language: compact, neutral, data-dense, Excel green used sparingly.

## Wrap everything in `TaskPaneProvider`

Every screen must be wrapped once in `TaskPaneProvider`. It supplies the MUI
theme (`theme`), `CssBaseline`, a react-query `QueryClientProvider`, and the
`ToastProvider` / `ConfirmProvider` contexts. Without it components render in
MUI defaults (blue accent, Roboto) and anything calling `useToast()` or
`useConfirm()` throws.

```tsx
const { TaskPaneProvider, ReportBuilder } = window.TessalliteExcel;
<TaskPaneProvider>
  <ReportBuilder projectId="proj-sales" modelId="model-sales" serverUrl="https://tessallite.example" />
</TaskPaneProvider>
```

`ExcelChatShell` additionally needs an `adapter` (`AgentChatAdapter`) and `t`.

## Styling idiom: MUI `sx` with the `tokens` object - no CSS classes

There are no utility classes and no CSS custom properties. Layout glue is MUI
(`Box`, `Typography`, `Stack`) styled through `sx`, with colours and fonts from
`window.TessalliteExcel.tokens`:

| Token | Value | Use |
|---|---|---|
| `tokens.colorPrimary` | `#217346` | Excel green: primary buttons, active tab, selection |
| `tokens.colorPrimaryDark` | `#185a33` | pressed / hover on primary |
| `tokens.colorPrimaryBg` | `rgba(33,115,70,0.07)` | selected row background |
| `tokens.colorBackground` / `colorWhite` | `#FFFFFF` | pane background |
| `tokens.colorSubtleFill` | `#F5F5F5` | section headers, footer, hover |
| `tokens.colorBorderLight` / `colorBorder` | `#E1E1E1` / `#D1D1D1` | dividers, inputs |
| `tokens.colorCharcoal` | `#242424` | primary text |
| `tokens.colorTextSecondary` | `#616161` | captions, secondary text |
| `tokens.colorRed` / `colorRedBg` | `#B33A3A` / `#FFEBEE` | errors, poor KPI status |
| `tokens.colorGold` / `colorGoldDark` / `colorGoldBg` | `#D4AF37` / `#A67C00` | warnings, calculated/KPI chips, reconnecting |
| `tokens.colorPurple` / `colorPurpleBg` | `#6B4C8A` | variant measures |
| `tokens.fontSans` | Segoe UI stack | all text; body 13px, captions 10-11px |
| `tokens.fontMono` | Cascadia Code stack | SQL and query traces |

Spacing is a 4px rhythm (`sx={{ px: 1.5, py: 0.75 }}`), 16-20px outer margins.
Buttons are `size="small"`; icon buttons 18px; chips 10-11px uppercase.

## Task-pane frame: real shell components

The pane is 320-350px wide (use `width: 340`, `minWidth: 320`) and stacks, top
to bottom: `AppHeader` (48px: brand mark, title, drill/glossary/profile/settings
actions), `ProjectBar` (project selector), `ModeTabs` (44px, Analyse / KPIs /
Ask; pass `mode`, `onModeChange`, `askLabel`), an optional `OfflineBanner`
(`onRetry`), the screen (`ReportBuilder`, `KpiPanel` or `ExcelChatShell`) in a
`role="tabpanel"` box with `flex: 1; minHeight: 0; overflow: auto`, and
`AppFooter` (28px: `email`, `personas`, `activePersonaId`, `onPersonaSelect`,
`connected`, `reconnecting`). Give the screen container `position: relative` -
`DrillPanel` fills its positioned parent.

```tsx
const { TaskPaneProvider, AppHeader, ProjectBar, ModeTabs, AppFooter, ReportBuilder } = window.TessalliteExcel;
<TaskPaneProvider>
  <Box sx={{ width: 340, height: '100vh', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
    <AppHeader profiles={profiles} activeProfile={profiles[0]} onOpenDrill={noop} onOpenGlossary={noop}
      onOpenDiagnostics={noop} onSwitchProfile={noop} onRemoveProfile={noop} onLogout={noop} />
    <ProjectBar projects={projects} projectId={projectId} onProjectChange={setProjectId} />
    <ModeTabs mode={mode} onModeChange={setMode} askLabel="Ask Tessallite" />
    <Box role="tabpanel" sx={{ flex: 1, minHeight: 0, overflow: 'auto', position: 'relative' }}>
      <ReportBuilder projectId="proj-sales" modelId="model-sales" serverUrl="https://tessallite.example" />
    </Box>
    <AppFooter email="j.doe@acme.example" personas={personas} activePersonaId={personaId}
      onPersonaSelect={(p) => setPersonaId(p?.id ?? null)} connected reconnecting={false} />
  </Box>
</TaskPaneProvider>
```

## Where the truth lives

- `components/<group>/<Name>/<Name>.d.ts` - exact props; `<Name>.prompt.md` -
  usage and examples.
- `guidelines/` - `design-guidelines.md` (design language) and
  `architecture_frontend-design.md` (every screen, state and interaction).
- Composable parts for new screens: primitives (`SectionHeader`, `SearchBar`,
  `StatusBadge`, `EmptyState`, `LoadingSkeleton`), the Report Builder
  vocabulary (`ZoneMappingGrid`, `MeasureLibrary`, `DimensionLibrary`,
  `KpiLibrary`, `NamedSetLibrary`, `HierarchyLibrary`, `MeasureCard`,
  `DimensionCard`, `KpiCard`, `TemplatePicker`), overlays (`GlossaryModal`,
  `TraceModal`, `DrillPanel`, `CubeFormulaWizard`, `LiveConnectionWizard`) and
  identity (`LoginScreen`, `ProfileSwitcher`, `PersonaDropdown`) and the shell
  (`AppHeader`, `ProjectBar`, `ModeTabs`, `OfflineBanner`, `AppFooter`).

## Idiomatic snippet

```tsx
const { TaskPaneProvider, SectionHeader, MeasureLibrary, StatusBadge, tokens } = window.TessalliteExcel;
<TaskPaneProvider>
  <Box sx={{ width: 340, bgcolor: tokens.colorWhite, fontFamily: tokens.fontSans }}>
    <MeasureLibrary measures={measures} searchQuery="" selectedMeasureIds={[]} expanded
      onToggleMeasure={() => {}} onAddToValues={() => {}} onToggleExpanded={() => {}} />
    <Box sx={{ height: 28, display: 'flex', alignItems: 'center', px: 2, bgcolor: tokens.colorSubtleFill,
               borderTop: `1px solid ${tokens.colorBorderLight}` }}>
      <StatusBadge status="connected" label="Connected" />
    </Box>
  </Box>
</TaskPaneProvider>
```

# TessalliteExcel (tessallite-excel-plugin@0.1.0)

This design system is the published tessallite-excel-plugin React library, bundled as a single
browser global. All 39 components are the real upstream code.

## Where things are

- `_ds_bundle.js` — the whole-DS bundle at the project root; loads every component to `window.TessalliteExcel`. First line is a `/* @ds-bundle: … */` metadata header.
- `styles.css` — the single stylesheet entry (tokens and fonts; this DS injects component styles at runtime). Link this one file.
- `components/<group>/<Name>/<Name>.prompt.md` (example JSX + variants), `<Name>.d.ts` (types), `<Name>.html` (variant grid).
- `tokens/*.css` — CSS custom properties, names verbatim from upstream.
- `fonts/` — `@font-face` files + `fonts.css` (when the package ships fonts).
- `guidelines/` — the design system's own usage guidance (2 doc(s), see `guidelines/index.md`). Read these before composing larger layouts.

For a specific component, `read_file("components/<group>/<Name>/<Name>.prompt.md")`.

## Loading

Add these two lines to your page once (React must be on the page first):

```html
<link rel="stylesheet" href="styles.css">
<script src="_ds_bundle.js"></script>
```

Components are then available at `window.TessalliteExcel.*`. Mount into a dedicated child node (e.g. `<div id="ds-root">`), not the host page's own React root, so the two trees don't collide:

```jsx
const { AppFooter } = window.TessalliteExcel;
ReactDOM.createRoot(document.getElementById('ds-root')).render(<AppFooter />);
```

Wrap the tree in the provider — most components read theme/i18n from context:

```jsx
<TaskPaneProvider>{children}</TaskPaneProvider>
```

## Tokens

0 CSS custom properties from tessallite-excel-plugin. Names are
preserved verbatim from upstream. None detected — this DS may compute styles at runtime (CSS-in-JS).



## Components

### shell
- `AppFooter`
- `AppHeader`
- `ModeTabs`
- `OfflineBanner`
- `ProjectBar`

### cubefunctions
- `CubeFormulaWizard`

### settings
- `DiagnosticsPanel`

### reportbuilder
- `DimensionCard`
- `DimensionLibrary`
- `HierarchyCard`
- `HierarchyLibrary`
- `KpiCard`
- `KpiLibrary`
- `MeasureCard`
- `MeasureLibrary`
- `NamedSetCard`
- `NamedSetLibrary`
- `RefreshDetailsPanel`
- `TemplateCard`
- `TemplatePicker`
- `VirtualList`
- `ZoneMappingGrid`

### drillthrough
- `DrillPanel`
- `DrillPathPicker`

### common
- `EmptyState`
- `LoadingSkeleton`
- `SearchBar`
- `SectionHeader`
- `StatusBadge`

### asktessallite
- `ExcelChatShell`
- `InsertActions`

### glossary
- `GlossaryModal`

### screens
- `KpiPanel`
- `ReportBuilder`

### connection
- `LiveConnectionWizard`

### identity
- `LoginScreen`
- `ProfileSwitcher`

### personaswitcher
- `PersonaDropdown`

### querytrace
- `TraceModal`
