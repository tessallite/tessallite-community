// Re-export of tessallite-excel-plugin@0.1.0 MeasureCard. Implementation is in the root _ds_bundle.js (window.TessalliteExcel).
Object.assign(window, { MeasureCard: window.TessalliteExcel.MeasureCard });
