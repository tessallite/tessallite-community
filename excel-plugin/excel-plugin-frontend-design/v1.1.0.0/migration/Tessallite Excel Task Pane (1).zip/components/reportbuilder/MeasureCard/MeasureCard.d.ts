import * as React from 'react';

/**
 * MeasureCard — from tessallite-excel-plugin@0.1.0.
 */
export interface MeasureCardProps {
  measure: Measure;
  checked: boolean;
  onToggle: () => void;
  onAddToValues: () => void;
  /** Bug-9747: add a HAVING-style filter on this measure's aggregated value. */
  onAddToFilter?: () => void;
  /** Phase A default: insert as TESSALLITE.VALUE() formula (connectionless). */
  onInsertAsFunction?: () => void;
  /** Advanced: insert as CUBEVALUE formula (requires workbook connection). */
  onInsertAsFormula?: () => void;
  glossaryEntries?: GlossaryEntry[];
}

export declare const MeasureCard: React.ComponentType<MeasureCardProps>;
