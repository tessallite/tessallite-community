MeasureCard from tessallite-excel-plugin. Use via `window.TessalliteExcel.MeasureCard` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface MeasureCardProps {
  measure: Measure;
  checked: boolean;
  onToggle: () => void;
  onAddToValues: () => void;
  /** Bug-9747: add a HAVING-style filter on this measure's aggregated value. */
  onAddToFilter?: () => void;
  /** Phase A default: insert as TESSALLITE.VALUE() formula (connectionless). */
  onInsertAsFunction?: () => void;
  /** Advanced: insert as CUBEVALUE formula (requires workbook connection). */
  onInsertAsFormula?: () => void;
  glossaryEntries?: GlossaryEntry[];
}
```
