DimensionLibrary from tessallite-excel-plugin. Use via `window.TessalliteExcel.DimensionLibrary` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface DimensionLibraryProps {
  dimensions: Dimension[];
  searchQuery: string;
  onAddToRows: (dimensionId: string) => void;
  onAddToColumns: (dimensionId: string) => void;
  onAddToFilter: (dimensionId: string) => void;
  onPreviewMembers: (dimensionId: string) => void;
  expanded: boolean;
  onToggleExpanded: () => void;
  loading?: boolean;
  memberPreviewDimId: string;
  memberPreview: DiscoverMembersResponse;
  membersPreviewLoading: boolean;
  onCloseMemberPreview: () => void;
  compatibilityByDimensionId?: Record<string, DimensionCompatibilityState>;
}
```
