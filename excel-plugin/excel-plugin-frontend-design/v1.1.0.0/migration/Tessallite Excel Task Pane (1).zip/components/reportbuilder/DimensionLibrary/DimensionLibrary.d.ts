import * as React from 'react';

/**
 * DimensionLibrary — from tessallite-excel-plugin@0.1.0.
 */
export interface DimensionLibraryProps {
  dimensions: Dimension[];
  searchQuery: string;
  onAddToRows: (dimensionId: string) => void;
  onAddToColumns: (dimensionId: string) => void;
  onAddToFilter: (dimensionId: string) => void;
  onPreviewMembers: (dimensionId: string) => void;
  expanded: boolean;
  onToggleExpanded: () => void;
  loading?: boolean;
  memberPreviewDimId: string;
  memberPreview: DiscoverMembersResponse;
  membersPreviewLoading: boolean;
  onCloseMemberPreview: () => void;
  compatibilityByDimensionId?: Record<string, DimensionCompatibilityState>;
}

export declare const DimensionLibrary: React.ComponentType<DimensionLibraryProps>;
