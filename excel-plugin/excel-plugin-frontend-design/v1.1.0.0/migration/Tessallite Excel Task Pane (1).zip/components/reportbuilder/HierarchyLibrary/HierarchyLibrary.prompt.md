HierarchyLibrary from tessallite-excel-plugin. Use via `window.TessalliteExcel.HierarchyLibrary` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface HierarchyLibraryProps {
  hierarchies: Hierarchy[];
  expanded: boolean;
  onToggle: () => void;
  onAssignToRows: (hierarchy: Hierarchy, level?: HierarchyLevel) => void;
}
```
