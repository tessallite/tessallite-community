import * as React from 'react';

/**
 * HierarchyLibrary — from tessallite-excel-plugin@0.1.0.
 */
export interface HierarchyLibraryProps {
  hierarchies: Hierarchy[];
  expanded: boolean;
  onToggle: () => void;
  onAssignToRows: (hierarchy: Hierarchy, level?: HierarchyLevel) => void;
}

export declare const HierarchyLibrary: React.ComponentType<HierarchyLibraryProps>;
