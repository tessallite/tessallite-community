import * as React from 'react';

/**
 * HierarchyCard — from tessallite-excel-plugin@0.1.0.
 */
export interface HierarchyCardProps {
  hierarchy: Hierarchy;
  onAssignToRows: (level?: HierarchyLevel) => void;
}

export declare const HierarchyCard: React.ComponentType<HierarchyCardProps>;
