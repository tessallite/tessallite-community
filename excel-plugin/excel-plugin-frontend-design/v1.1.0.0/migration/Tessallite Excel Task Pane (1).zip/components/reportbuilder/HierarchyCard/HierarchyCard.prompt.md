HierarchyCard from tessallite-excel-plugin. Use via `window.TessalliteExcel.HierarchyCard` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface HierarchyCardProps {
  hierarchy: Hierarchy;
  onAssignToRows: (level?: HierarchyLevel) => void;
}
```
