MeasureLibrary from tessallite-excel-plugin. Use via `window.TessalliteExcel.MeasureLibrary` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface MeasureLibraryProps {
  measures: Measure[];
  searchQuery: string;
  selectedMeasureIds: string[];
  onToggleMeasure: (measureId: string) => void;
  onAddToValues: (measureId: string) => void;
  /** Bug-9747: add a HAVING-style filter on the measure's aggregated value. */
  onAddToFilter?: (measureId: string) => void;
  /** Phase A default: insert as TESSALLITE.VALUE() formula (connectionless). */
  onInsertMeasureAsFunction?: (measureId: string) => void;
  /** Advanced: insert as CUBEVALUE formula (requires workbook connection). */
  onInsertMeasureAsFormula?: (measureId: string) => void;
  expanded: boolean;
  onToggleExpanded: () => void;
  loading?: boolean;
  glossaryEntries?: GlossaryEntry[];
}
```
