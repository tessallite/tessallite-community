import * as React from 'react';

/**
 * MeasureLibrary — from tessallite-excel-plugin@0.1.0.
 */
export interface MeasureLibraryProps {
  measures: Measure[];
  searchQuery: string;
  selectedMeasureIds: string[];
  onToggleMeasure: (measureId: string) => void;
  onAddToValues: (measureId: string) => void;
  /** Bug-9747: add a HAVING-style filter on the measure's aggregated value. */
  onAddToFilter?: (measureId: string) => void;
  /** Phase A default: insert as TESSALLITE.VALUE() formula (connectionless). */
  onInsertMeasureAsFunction?: (measureId: string) => void;
  /** Advanced: insert as CUBEVALUE formula (requires workbook connection). */
  onInsertMeasureAsFormula?: (measureId: string) => void;
  expanded: boolean;
  onToggleExpanded: () => void;
  loading?: boolean;
  glossaryEntries?: GlossaryEntry[];
}

export declare const MeasureLibrary: React.ComponentType<MeasureLibraryProps>;
