import * as React from 'react';

/**
 * TemplateCard — from tessallite-excel-plugin@0.1.0.
 */
export interface TemplateCardProps {
  template: ReportTemplate;
  isApplicable: boolean;
  missingFields: string[];
  onSelect: (template: ReportTemplate) => void;
}

export declare const TemplateCard: React.ComponentType<TemplateCardProps>;
