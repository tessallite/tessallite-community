TemplateCard from tessallite-excel-plugin. Use via `window.TessalliteExcel.TemplateCard` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface TemplateCardProps {
  template: ReportTemplate;
  isApplicable: boolean;
  missingFields: string[];
  onSelect: (template: ReportTemplate) => void;
}
```
