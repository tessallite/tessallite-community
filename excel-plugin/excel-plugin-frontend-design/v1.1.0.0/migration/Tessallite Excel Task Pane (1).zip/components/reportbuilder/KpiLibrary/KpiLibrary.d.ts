import * as React from 'react';

/**
 * KpiLibrary — from tessallite-excel-plugin@0.1.0.
 */
export interface KpiLibraryProps {
  kpis: Kpi[];
  measures: Measure[];
  projectId: string;
  modelId: string;
  personaId?: string;
  searchQuery: string;
  selectedKpiValueMeasureIds: string[];
  onToggleKpi: (kpi: Kpi) => void;
  onAddKpiToValues: (kpi: Kpi) => void;
  onInsertKpiAsFormulas?: (kpi: Kpi) => void;
  onInsertKpi?: (kpi: Kpi, mode: KpiInsertMode) => void;
  onInsertScorecard?: () => void;
  expanded: boolean;
  onToggleExpanded: () => void;
  loading?: boolean;
}

export declare const KpiLibrary: React.ComponentType<KpiLibraryProps>;
