// Re-export of tessallite-excel-plugin@0.1.0 KpiLibrary. Implementation is in the root _ds_bundle.js (window.TessalliteExcel).
Object.assign(window, { KpiLibrary: window.TessalliteExcel.KpiLibrary });
