KpiLibrary from tessallite-excel-plugin. Use via `window.TessalliteExcel.KpiLibrary` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface KpiLibraryProps {
  kpis: Kpi[];
  measures: Measure[];
  projectId: string;
  modelId: string;
  personaId?: string;
  searchQuery: string;
  selectedKpiValueMeasureIds: string[];
  onToggleKpi: (kpi: Kpi) => void;
  onAddKpiToValues: (kpi: Kpi) => void;
  onInsertKpiAsFormulas?: (kpi: Kpi) => void;
  onInsertKpi?: (kpi: Kpi, mode: KpiInsertMode) => void;
  onInsertScorecard?: () => void;
  expanded: boolean;
  onToggleExpanded: () => void;
  loading?: boolean;
}
```
