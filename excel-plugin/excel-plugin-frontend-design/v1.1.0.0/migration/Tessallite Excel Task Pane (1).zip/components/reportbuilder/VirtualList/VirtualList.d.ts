import * as React from 'react';

/**
 * VirtualList — from tessallite-excel-plugin@0.1.0.
 */
export interface VirtualListProps<T> {
  items: T[];
  itemHeight: number;
  maxVisibleItems?: number;
  renderItem: (item: T, index: number) => ReactNode;
  listHeight?: number;
}

export declare const VirtualList: React.ComponentType<VirtualListProps>;
