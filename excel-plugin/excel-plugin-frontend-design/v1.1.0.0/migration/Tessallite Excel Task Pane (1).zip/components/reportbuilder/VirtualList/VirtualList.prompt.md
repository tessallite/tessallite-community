VirtualList from tessallite-excel-plugin. Use via `window.TessalliteExcel.VirtualList` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface VirtualListProps {
  items: T[];
  itemHeight: number;
  maxVisibleItems?: number;
  renderItem: (item: T, index: number) => ReactNode;
  listHeight?: number;
}
```
