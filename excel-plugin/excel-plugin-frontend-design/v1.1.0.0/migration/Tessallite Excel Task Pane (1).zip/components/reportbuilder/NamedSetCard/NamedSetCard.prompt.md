NamedSetCard from tessallite-excel-plugin. Use via `window.TessalliteExcel.NamedSetCard` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface NamedSetCardProps {
  namedSet: NamedSet;
  projectId: string;
  modelId: string;
  personaId?: string;
  onAddToRows: () => void;
  onAddToColumns: () => void;
  onAddToFilter: () => void;
  onInsertAsFormulas?: () => void;
}
```
