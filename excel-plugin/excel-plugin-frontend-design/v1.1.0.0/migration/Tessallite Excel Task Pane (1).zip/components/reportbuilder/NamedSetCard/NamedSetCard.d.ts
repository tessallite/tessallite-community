import * as React from 'react';

/**
 * NamedSetCard — from tessallite-excel-plugin@0.1.0.
 */
export interface NamedSetCardProps {
  namedSet: NamedSet;
  projectId: string;
  modelId: string;
  personaId?: string;
  onAddToRows: () => void;
  onAddToColumns: () => void;
  onAddToFilter: () => void;
  onInsertAsFormulas?: () => void;
}

export declare const NamedSetCard: React.ComponentType<NamedSetCardProps>;
