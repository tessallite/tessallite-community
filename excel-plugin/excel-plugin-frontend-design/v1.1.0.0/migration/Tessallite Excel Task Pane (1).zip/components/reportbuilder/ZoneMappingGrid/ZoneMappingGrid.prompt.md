ZoneMappingGrid from tessallite-excel-plugin. Use via `window.TessalliteExcel.ZoneMappingGrid` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface ZoneMappingGridProps {
  items: ZoneItem[];
  onRemove: (id: string, zone: Zone) => void;
  onClear: () => void;
  onInsertTable: () => void;
  onInsertChart?: () => void;
  onInsertLocalPivot?: () => void;
  onOpenTemplates: () => void;
  onUpdateFilter?: (id: string, operator: string, values: string[]) => void;
  compatibilityWarning?: { title: string; messages: string[]; compatibleDimensionNames?: string[]; };
  insertDisabledReason?: string;
}
```
