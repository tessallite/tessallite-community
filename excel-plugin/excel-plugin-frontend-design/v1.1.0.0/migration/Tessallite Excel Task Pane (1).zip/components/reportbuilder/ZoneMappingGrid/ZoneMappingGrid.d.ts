import * as React from 'react';

/**
 * ZoneMappingGrid — from tessallite-excel-plugin@0.1.0.
 */
export interface ZoneMappingGridProps {
  items: ZoneItem[];
  onRemove: (id: string, zone: Zone) => void;
  onClear: () => void;
  onInsertTable: () => void;
  onInsertChart?: () => void;
  onInsertLocalPivot?: () => void;
  onOpenTemplates: () => void;
  onUpdateFilter?: (id: string, operator: string, values: string[]) => void;
  compatibilityWarning?: { title: string; messages: string[]; compatibleDimensionNames?: string[]; };
  insertDisabledReason?: string;
}

export declare const ZoneMappingGrid: React.ComponentType<ZoneMappingGridProps>;
