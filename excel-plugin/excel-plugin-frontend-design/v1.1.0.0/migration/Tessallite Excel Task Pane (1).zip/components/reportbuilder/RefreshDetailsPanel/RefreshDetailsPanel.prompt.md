RefreshDetailsPanel from tessallite-excel-plugin. Use via `window.TessalliteExcel.RefreshDetailsPanel` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface RefreshDetailsPanelProps {
  /** Tables that were skipped or refreshed with a warning during a sheet refresh. */
  rows: { name: string; reason: string; kind: 'skipped' | 'warning' }[];
}
```
