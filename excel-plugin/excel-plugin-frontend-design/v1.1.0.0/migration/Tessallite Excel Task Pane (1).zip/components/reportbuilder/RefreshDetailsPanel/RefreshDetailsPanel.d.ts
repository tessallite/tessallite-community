import * as React from 'react';

/**
 * RefreshDetailsPanel — from tessallite-excel-plugin@0.1.0.
 */
export interface RefreshDetailsPanelProps {
  /** Tables that were skipped or refreshed with a warning during a sheet refresh. */
  rows: { name: string; reason: string; kind: 'skipped' | 'warning' }[];
}

export declare const RefreshDetailsPanel: React.ComponentType<RefreshDetailsPanelProps>;
