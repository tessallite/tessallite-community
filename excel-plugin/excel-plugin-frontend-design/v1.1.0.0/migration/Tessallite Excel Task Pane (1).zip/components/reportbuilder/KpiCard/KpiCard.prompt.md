KpiCard from tessallite-excel-plugin. Use via `window.TessalliteExcel.KpiCard` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface KpiCardProps {
  kpi: Kpi;
  measures: Measure[];
  projectId: string;
  modelId: string;
  personaId?: string;
  checked: boolean;
  onToggle: () => void;
  onAddToValues: () => void;
  onInsertAsFormulas?: () => void;
  onInsertKpi?: (mode: KpiInsertMode) => void;
}
```
