import * as React from 'react';

/**
 * KpiCard — from tessallite-excel-plugin@0.1.0.
 */
export interface KpiCardProps {
  kpi: Kpi;
  measures: Measure[];
  projectId: string;
  modelId: string;
  personaId?: string;
  checked: boolean;
  onToggle: () => void;
  onAddToValues: () => void;
  onInsertAsFormulas?: () => void;
  onInsertKpi?: (mode: KpiInsertMode) => void;
}

export declare const KpiCard: React.ComponentType<KpiCardProps>;
