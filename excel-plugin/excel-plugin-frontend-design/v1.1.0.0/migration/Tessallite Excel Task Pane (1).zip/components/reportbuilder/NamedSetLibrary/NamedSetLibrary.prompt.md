NamedSetLibrary from tessallite-excel-plugin. Use via `window.TessalliteExcel.NamedSetLibrary` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface NamedSetLibraryProps {
  namedSets: NamedSet[];
  searchQuery: string;
  projectId: string;
  modelId: string;
  personaId?: string;
  onAddToRows: (ns: NamedSet) => void;
  onAddToColumns: (ns: NamedSet) => void;
  onAddToFilter: (ns: NamedSet) => void;
  onInsertAsFormulas?: (ns: NamedSet) => void;
  expanded: boolean;
  onToggleExpanded: () => void;
  loading?: boolean;
}
```
