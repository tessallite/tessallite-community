import * as React from 'react';

/**
 * NamedSetLibrary — from tessallite-excel-plugin@0.1.0.
 */
export interface NamedSetLibraryProps {
  namedSets: NamedSet[];
  searchQuery: string;
  projectId: string;
  modelId: string;
  personaId?: string;
  onAddToRows: (ns: NamedSet) => void;
  onAddToColumns: (ns: NamedSet) => void;
  onAddToFilter: (ns: NamedSet) => void;
  onInsertAsFormulas?: (ns: NamedSet) => void;
  expanded: boolean;
  onToggleExpanded: () => void;
  loading?: boolean;
}

export declare const NamedSetLibrary: React.ComponentType<NamedSetLibraryProps>;
