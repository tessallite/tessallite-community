// Re-export of tessallite-excel-plugin@0.1.0 DimensionCard. Implementation is in the root _ds_bundle.js (window.TessalliteExcel).
Object.assign(window, { DimensionCard: window.TessalliteExcel.DimensionCard });
