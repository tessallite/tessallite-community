import * as React from 'react';

/**
 * DimensionCard — from tessallite-excel-plugin@0.1.0.
 */
export interface DimensionCardProps {
  id: string;
  displayName: string;
  description?: string;
  dataType: string;
  sourceType: "dim" | "calculated";
  isTimeDimension?: boolean;
  calendarType?: string;
  compatibility?: DimensionCompatibilityState;
  onAssign: (zone: "rows" | "columns" | "filter" | "slicer") => void;
  onPreviewMembers?: (id: string) => void;
}

export declare const DimensionCard: React.ComponentType<DimensionCardProps>;
