DimensionCard from tessallite-excel-plugin. Use via `window.TessalliteExcel.DimensionCard` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface DimensionCardProps {
  id: string;
  displayName: string;
  description?: string;
  dataType: string;
  sourceType: "dim" | "calculated";
  isTimeDimension?: boolean;
  calendarType?: string;
  compatibility?: DimensionCompatibilityState;
  onAssign: (zone: "rows" | "columns" | "filter" | "slicer") => void;
  onPreviewMembers?: (id: string) => void;
}
```
