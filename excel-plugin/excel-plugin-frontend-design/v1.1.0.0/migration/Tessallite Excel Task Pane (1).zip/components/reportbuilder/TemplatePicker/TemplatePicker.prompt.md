TemplatePicker from tessallite-excel-plugin. Use via `window.TessalliteExcel.TemplatePicker` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface TemplatePickerProps {
  open: boolean;
  onClose: () => void;
  onSelect: (template: ReportTemplate) => void;
  measureCount: number;
  hasTimeDimension: boolean;
  hasCategoricalDimension: boolean;
}
```
