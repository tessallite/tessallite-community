import * as React from 'react';

/**
 * TemplatePicker — from tessallite-excel-plugin@0.1.0.
 */
export interface TemplatePickerProps {
  open: boolean;
  onClose: () => void;
  onSelect: (template: ReportTemplate) => void;
  measureCount: number;
  hasTimeDimension: boolean;
  hasCategoricalDimension: boolean;
}

export declare const TemplatePicker: React.ComponentType<TemplatePickerProps>;
