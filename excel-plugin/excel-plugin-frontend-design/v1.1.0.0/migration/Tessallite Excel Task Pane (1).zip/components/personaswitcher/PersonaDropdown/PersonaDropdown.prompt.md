PersonaDropdown from tessallite-excel-plugin. Use via `window.TessalliteExcel.PersonaDropdown` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface PersonaDropdownProps {
  personas: Persona[];
  activePersonaId: string;
  onSelect: (persona: Persona | null) => void;
}
```
