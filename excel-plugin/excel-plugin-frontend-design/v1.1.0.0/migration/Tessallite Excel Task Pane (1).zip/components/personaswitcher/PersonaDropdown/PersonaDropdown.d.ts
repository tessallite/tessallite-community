import * as React from 'react';

/**
 * PersonaDropdown — from tessallite-excel-plugin@0.1.0.
 */
export interface PersonaDropdownProps {
  personas: Persona[];
  activePersonaId: string;
  onSelect: (persona: Persona | null) => void;
}

export declare const PersonaDropdown: React.ComponentType<PersonaDropdownProps>;
