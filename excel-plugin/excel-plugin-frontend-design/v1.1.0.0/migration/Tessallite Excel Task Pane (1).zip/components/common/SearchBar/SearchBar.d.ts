import * as React from 'react';

/**
 * SearchBar — from tessallite-excel-plugin@0.1.0.
 */
export interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  disabled?: boolean;
}

export declare const SearchBar: React.ComponentType<SearchBarProps>;
