import * as React from 'react';

/**
 * LoadingSkeleton — from tessallite-excel-plugin@0.1.0.
 */
export interface LoadingSkeletonProps {
  variant: "table" | "card" | "list" | "chat";
  count?: number;
}

export declare const LoadingSkeleton: React.ComponentType<LoadingSkeletonProps>;
