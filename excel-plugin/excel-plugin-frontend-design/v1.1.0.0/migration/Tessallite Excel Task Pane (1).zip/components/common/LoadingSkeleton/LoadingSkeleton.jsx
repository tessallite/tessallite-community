// Re-export of tessallite-excel-plugin@0.1.0 LoadingSkeleton. Implementation is in the root _ds_bundle.js (window.TessalliteExcel).
Object.assign(window, { LoadingSkeleton: window.TessalliteExcel.LoadingSkeleton });
