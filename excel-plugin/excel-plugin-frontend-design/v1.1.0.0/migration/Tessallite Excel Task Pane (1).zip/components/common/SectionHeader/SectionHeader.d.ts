import * as React from 'react';

/**
 * SectionHeader — from tessallite-excel-plugin@0.1.0.
 */
export interface SectionHeaderProps {
  title: string;
  count?: number;
  collapsed: boolean;
  onToggle: () => void;
}

export declare const SectionHeader: React.ComponentType<SectionHeaderProps>;
