import * as React from 'react';

/**
 * EmptyState — from tessallite-excel-plugin@0.1.0.
 */
export interface EmptyStateProps {
  icon?: React.ReactNode;
  title: string;
  description?: string;
  action?: { label: string; onClick: () => void; };
}

export declare const EmptyState: React.ComponentType<EmptyStateProps>;
