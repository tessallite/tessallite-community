StatusBadge from tessallite-excel-plugin. Use via `window.TessalliteExcel.StatusBadge` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface StatusBadgeProps {
  status: "connected" | "disconnected" | "reconnecting" | "active" | "inactive";
  label: string;
  size?: "small" | "medium";
}
```
