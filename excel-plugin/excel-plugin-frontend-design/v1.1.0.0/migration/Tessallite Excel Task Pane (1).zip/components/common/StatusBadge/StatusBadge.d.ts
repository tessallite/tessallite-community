import * as React from 'react';

/**
 * StatusBadge — from tessallite-excel-plugin@0.1.0.
 */
export interface StatusBadgeProps {
  status: "connected" | "disconnected" | "reconnecting" | "active" | "inactive";
  label: string;
  size?: "small" | "medium";
}

export declare const StatusBadge: React.ComponentType<StatusBadgeProps>;
