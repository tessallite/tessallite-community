InsertActions from tessallite-excel-plugin. Use via `window.TessalliteExcel.InsertActions` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface InsertActionsProps {
  data: Record<string, unknown>[];
  headers: string[];
  onInsertTable?: () => void;
  onInsertChart?: () => void;
  onLocalPivot?: () => void;
  onCubeFormulas?: () => void;
  onLiveConnection?: () => void;
  onShowQuery?: () => void;
  recommendedAction?: "table" | "chart" | "pivot" | "cube";
}
```
