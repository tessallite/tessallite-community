import * as React from 'react';

/**
 * InsertActions — from tessallite-excel-plugin@0.1.0.
 */
export interface InsertActionsProps {
  data: Record<string, unknown>[];
  headers: string[];
  onInsertTable?: () => void;
  onInsertChart?: () => void;
  onLocalPivot?: () => void;
  onCubeFormulas?: () => void;
  onLiveConnection?: () => void;
  onShowQuery?: () => void;
  recommendedAction?: "table" | "chart" | "pivot" | "cube";
}

export declare const InsertActions: React.ComponentType<InsertActionsProps>;
