ExcelChatShell from tessallite-excel-plugin. Use via `window.TessalliteExcel.ExcelChatShell` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface ExcelChatShellProps {
  adapter: AgentChatAdapter;
  t: (key: string, params?: Record<string, string | number>) => string;
  projectId: string;
  config: any;
  activeModelId: string;
  activePersonaId?: string;
  agentConfigured: boolean;
  providerModel?: string;
  loading?: boolean;
  error?: string;
  onInsertTable?: (turn: TurnResponse) => void;
  onInsertChart?: (turn: TurnResponse, chartType?: ChartTypeRecommendation) => void;
  onInsertLocalPivot?: (turn: TurnResponse) => void;
  onFeedback?: (turnId: string, vote: "up" | "down") => void;
}
```
