import * as React from 'react';

/**
 * ExcelChatShell — from tessallite-excel-plugin@0.1.0.
 */
export interface ExcelChatShellProps {
  adapter: AgentChatAdapter;
  t: (key: string, params?: Record<string, string | number>) => string;
  projectId: string;
  config: any;
  activeModelId: string;
  activePersonaId?: string;
  agentConfigured: boolean;
  providerModel?: string;
  loading?: boolean;
  error?: string;
  onInsertTable?: (turn: TurnResponse) => void;
  onInsertChart?: (turn: TurnResponse, chartType?: ChartTypeRecommendation) => void;
  onInsertLocalPivot?: (turn: TurnResponse) => void;
  onFeedback?: (turnId: string, vote: "up" | "down") => void;
}

export declare const ExcelChatShell: React.ComponentType<ExcelChatShellProps>;
