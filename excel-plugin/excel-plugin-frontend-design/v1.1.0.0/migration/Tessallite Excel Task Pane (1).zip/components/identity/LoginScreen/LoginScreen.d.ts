import * as React from 'react';

/**
 * LoginScreen — from tessallite-excel-plugin@0.1.0.
 */
export interface LoginScreenProps {
  onLogin: (data: LoginFormData, remember: boolean) => Promise<void>;
  loading: boolean;
  error: string;
}

export declare const LoginScreen: React.ComponentType<LoginScreenProps>;
