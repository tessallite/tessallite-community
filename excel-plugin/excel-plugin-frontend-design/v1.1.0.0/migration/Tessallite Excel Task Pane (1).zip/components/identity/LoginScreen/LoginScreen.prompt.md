LoginScreen from tessallite-excel-plugin. Use via `window.TessalliteExcel.LoginScreen` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface LoginScreenProps {
  onLogin: (data: LoginFormData, remember: boolean) => Promise<void>;
  loading: boolean;
  error: string;
}
```
