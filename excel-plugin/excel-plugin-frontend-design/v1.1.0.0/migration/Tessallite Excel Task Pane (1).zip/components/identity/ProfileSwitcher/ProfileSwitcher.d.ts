import * as React from 'react';

/**
 * ProfileSwitcher — from tessallite-excel-plugin@0.1.0.
 */
export interface ProfileSwitcherProps {
  profiles: ConnectionProfile[];
  activeProfile: ConnectionProfile;
  onSwitch: (profileId: string) => void;
  onRemove: (profileId: string) => void;
  onLogout: () => void;
}

export declare const ProfileSwitcher: React.ComponentType<ProfileSwitcherProps>;
