ProfileSwitcher from tessallite-excel-plugin. Use via `window.TessalliteExcel.ProfileSwitcher` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface ProfileSwitcherProps {
  profiles: ConnectionProfile[];
  activeProfile: ConnectionProfile;
  onSwitch: (profileId: string) => void;
  onRemove: (profileId: string) => void;
  onLogout: () => void;
}
```
