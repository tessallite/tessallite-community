import * as React from 'react';

/**
 * GlossaryModal — from tessallite-excel-plugin@0.1.0.
 */
export interface GlossaryModalProps {
  open: boolean;
  onClose: () => void;
  entries: GlossaryEntry[];
}

export declare const GlossaryModal: React.ComponentType<GlossaryModalProps>;
