KpiPanel from tessallite-excel-plugin. Use via `window.TessalliteExcel.KpiPanel` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface KpiPanelProps {
  projectId: string;
  modelId: string;
  personaId?: string;
  /** Bug-6903: model slug for TESSALLITE.KPI formula scorecard (live refresh). */
  modelSlug?: string;
  onInsertTable: (headers: string[], rows: (string | number)[][]) => Promise<{ address: string | null; postStepWarning: boolean; }>;
  onInsertChart: (headers: string[], rows: (string | number)[][]) => Promise<string | null>;
  onInsertScorecard: (kpis: EvaluatedScorecardKpi[], connectionName: string, modelSlug?: string) => Promise<string | null>;
  connectionName: string;
}
```
