import * as React from 'react';

/**
 * KpiPanel — from tessallite-excel-plugin@0.1.0.
 */
export interface KpiPanelProps {
  projectId: string;
  modelId: string;
  personaId?: string;
  /** Bug-6903: model slug for TESSALLITE.KPI formula scorecard (live refresh). */
  modelSlug?: string;
  onInsertTable: (headers: string[], rows: (string | number)[][]) => Promise<{ address: string | null; postStepWarning: boolean; }>;
  onInsertChart: (headers: string[], rows: (string | number)[][]) => Promise<string | null>;
  onInsertScorecard: (kpis: EvaluatedScorecardKpi[], connectionName: string, modelSlug?: string) => Promise<string | null>;
  connectionName: string;
}

export declare const KpiPanel: React.ComponentType<KpiPanelProps>;
