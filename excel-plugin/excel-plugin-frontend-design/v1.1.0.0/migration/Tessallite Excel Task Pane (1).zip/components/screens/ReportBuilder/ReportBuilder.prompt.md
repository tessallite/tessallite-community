ReportBuilder from tessallite-excel-plugin. Use via `window.TessalliteExcel.ReportBuilder` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface ReportBuilderProps {
  projectId: string;
  modelId: string;
  serverUrl: string;
  personaId?: string;
  personaSlug?: string;
  modelsList?: { id: string; name: string; slug?: string; }[];
  onModelChange?: (modelId: string) => void;
}
```
