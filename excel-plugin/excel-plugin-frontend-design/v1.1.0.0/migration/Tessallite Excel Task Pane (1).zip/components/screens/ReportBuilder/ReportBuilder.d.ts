import * as React from 'react';

/**
 * ReportBuilder — from tessallite-excel-plugin@0.1.0.
 */
export interface ReportBuilderProps {
  projectId: string;
  modelId: string;
  serverUrl: string;
  personaId?: string;
  personaSlug?: string;
  modelsList?: { id: string; name: string; slug?: string; }[];
  onModelChange?: (modelId: string) => void;
}

export declare const ReportBuilder: React.ComponentType<ReportBuilderProps>;
