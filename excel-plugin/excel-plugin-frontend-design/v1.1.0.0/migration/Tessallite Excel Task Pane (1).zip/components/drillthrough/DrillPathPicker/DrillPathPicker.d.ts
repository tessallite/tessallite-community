import * as React from 'react';

/**
 * DrillPathPicker — from tessallite-excel-plugin@0.1.0.
 */
export interface DrillPathPickerProps {
  options: DrillOption[];
  selectedPath: string;
  onSelect: (hierarchyId: string) => void;
}

export declare const DrillPathPicker: React.ComponentType<DrillPathPickerProps>;
