DrillPanel from tessallite-excel-plugin. Use via `window.TessalliteExcel.DrillPanel` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface DrillPanelProps {
  open: boolean;
  onClose: () => void;
  measureId: string;
  measureName: string;
  context: Record<string, unknown>;
  projectId?: string;
  modelId?: string;
  onInsertSheet: (headers: string[], rows: (string | number)[][]) => void;
}
```
