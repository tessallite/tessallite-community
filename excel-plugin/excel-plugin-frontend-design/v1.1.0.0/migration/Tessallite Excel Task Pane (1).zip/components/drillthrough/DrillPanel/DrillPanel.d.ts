import * as React from 'react';

/**
 * DrillPanel — from tessallite-excel-plugin@0.1.0.
 */
export interface DrillPanelProps {
  open: boolean;
  onClose: () => void;
  measureId: string;
  measureName: string;
  context: Record<string, unknown>;
  projectId?: string;
  modelId?: string;
  onInsertSheet: (headers: string[], rows: (string | number)[][]) => void;
}

export declare const DrillPanel: React.ComponentType<DrillPanelProps>;
