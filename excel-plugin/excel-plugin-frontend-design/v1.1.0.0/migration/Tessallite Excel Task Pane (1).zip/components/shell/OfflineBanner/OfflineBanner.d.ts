import * as React from 'react';

/**
 * OfflineBanner — from tessallite-excel-plugin@0.1.0.
 */
export interface OfflineBannerProps {
  onRetry: () => void;
}

export declare const OfflineBanner: React.ComponentType<OfflineBannerProps>;
