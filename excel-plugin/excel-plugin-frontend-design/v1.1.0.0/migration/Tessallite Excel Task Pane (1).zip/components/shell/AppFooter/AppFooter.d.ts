import * as React from 'react';

/**
 * AppFooter — from tessallite-excel-plugin@0.1.0.
 */
export interface AppFooterProps {
  /** Signed-in user's email; empty when no profile is active. */
  email: string;
  personas: Persona[];
  activePersonaId: string;
  onPersonaSelect: (persona: Persona | null) => void;
  connected: boolean;
  /** True while the connection is lost and being retried. */
  reconnecting: boolean;
}

export declare const AppFooter: React.ComponentType<AppFooterProps>;
