AppFooter from tessallite-excel-plugin. Use via `window.TessalliteExcel.AppFooter` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface AppFooterProps {
  /** Signed-in user's email; empty when no profile is active. */
  email: string;
  personas: Persona[];
  activePersonaId: string;
  onPersonaSelect: (persona: Persona | null) => void;
  connected: boolean;
  /** True while the connection is lost and being retried. */
  reconnecting: boolean;
}
```
