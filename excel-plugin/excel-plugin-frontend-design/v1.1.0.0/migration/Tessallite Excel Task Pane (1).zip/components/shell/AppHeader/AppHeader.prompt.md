AppHeader from tessallite-excel-plugin. Use via `window.TessalliteExcel.AppHeader` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface AppHeaderProps {
  profiles: ConnectionProfile[];
  activeProfile: ConnectionProfile;
  onOpenDrill: () => void;
  onOpenGlossary: () => void;
  onOpenDiagnostics: () => void;
  onSwitchProfile: (profileId: string) => void;
  onRemoveProfile: (profileId: string) => void;
  onLogout: () => void;
}
```
