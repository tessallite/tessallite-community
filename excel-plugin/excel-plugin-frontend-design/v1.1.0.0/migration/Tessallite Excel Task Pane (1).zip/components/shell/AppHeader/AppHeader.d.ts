import * as React from 'react';

/**
 * AppHeader — from tessallite-excel-plugin@0.1.0.
 */
export interface AppHeaderProps {
  profiles: ConnectionProfile[];
  activeProfile: ConnectionProfile;
  onOpenDrill: () => void;
  onOpenGlossary: () => void;
  onOpenDiagnostics: () => void;
  onSwitchProfile: (profileId: string) => void;
  onRemoveProfile: (profileId: string) => void;
  onLogout: () => void;
}

export declare const AppHeader: React.ComponentType<AppHeaderProps>;
