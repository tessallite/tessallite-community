ModeTabs from tessallite-excel-plugin. Use via `window.TessalliteExcel.ModeTabs` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface ModeTabsProps {
  mode: "ask" | "report-builder" | "kpi";
  onModeChange: (mode: AppMode) => void;
  /** Label of the Ask tab: the agent's display name when configured. */
  askLabel: string;
}
```
