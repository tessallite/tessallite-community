import * as React from 'react';

/**
 * ModeTabs — from tessallite-excel-plugin@0.1.0.
 */
export interface ModeTabsProps {
  mode: "ask" | "report-builder" | "kpi";
  onModeChange: (mode: AppMode) => void;
  /** Label of the Ask tab: the agent's display name when configured. */
  askLabel: string;
}

export declare const ModeTabs: React.ComponentType<ModeTabsProps>;
