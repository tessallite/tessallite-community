import * as React from 'react';

/**
 * ProjectBar — from tessallite-excel-plugin@0.1.0.
 */
export interface ProjectBarProps {
  projects: { id: string; name: string; }[];
  projectId: string;
  onProjectChange: (projectId: string) => void;
}

export declare const ProjectBar: React.ComponentType<ProjectBarProps>;
