ProjectBar from tessallite-excel-plugin. Use via `window.TessalliteExcel.ProjectBar` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface ProjectBarProps {
  projects: { id: string; name: string; }[];
  projectId: string;
  onProjectChange: (projectId: string) => void;
}
```
