TraceModal from tessallite-excel-plugin. Use via `window.TessalliteExcel.TraceModal` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface TraceModalProps {
  open: boolean;
  onClose: () => void;
  query: SemanticQuery;
  route?: PluginRouteTrace;
  modelName: string;
  personaName?: string;
}
```
