import * as React from 'react';

/**
 * TraceModal — from tessallite-excel-plugin@0.1.0.
 */
export interface TraceModalProps {
  open: boolean;
  onClose: () => void;
  query: SemanticQuery;
  route?: PluginRouteTrace;
  modelName: string;
  personaName?: string;
}

export declare const TraceModal: React.ComponentType<TraceModalProps>;
