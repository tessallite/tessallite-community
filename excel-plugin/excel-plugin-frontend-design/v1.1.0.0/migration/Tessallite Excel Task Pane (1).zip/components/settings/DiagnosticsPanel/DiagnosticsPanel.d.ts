import * as React from 'react';

/**
 * DiagnosticsPanel — from tessallite-excel-plugin@0.1.0.
 */
export interface DiagnosticsPanelProps {
  open: boolean;
  onClose: () => void;
}

export declare const DiagnosticsPanel: React.ComponentType<DiagnosticsPanelProps>;
