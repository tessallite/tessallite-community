import * as React from 'react';

/**
 * CubeFormulaWizard — from tessallite-excel-plugin@0.1.0.
 */
export interface CubeFormulaWizardProps {
  open: boolean;
  onClose: () => void;
  measures: Measure[];
  dimensions: Dimension[];
  projectId: string;
  modelId: string;
  personaId?: string;
  connectionName: string;
  onInsertFormula: (formula: string, targetCell: string) => void;
}

export declare const CubeFormulaWizard: React.ComponentType<CubeFormulaWizardProps>;
