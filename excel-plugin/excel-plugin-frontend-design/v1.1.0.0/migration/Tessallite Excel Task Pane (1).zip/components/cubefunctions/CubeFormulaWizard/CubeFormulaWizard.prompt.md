CubeFormulaWizard from tessallite-excel-plugin. Use via `window.TessalliteExcel.CubeFormulaWizard` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface CubeFormulaWizardProps {
  open: boolean;
  onClose: () => void;
  measures: Measure[];
  dimensions: Dimension[];
  projectId: string;
  modelId: string;
  personaId?: string;
  connectionName: string;
  onInsertFormula: (formula: string, targetCell: string) => void;
}
```
