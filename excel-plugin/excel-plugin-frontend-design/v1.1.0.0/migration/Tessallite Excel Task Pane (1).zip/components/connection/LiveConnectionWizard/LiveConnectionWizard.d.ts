import * as React from 'react';

/**
 * LiveConnectionWizard — from tessallite-excel-plugin@0.1.0.
 */
export interface LiveConnectionWizardProps {
  open: boolean;
  onClose: () => void;
  serverUrl: string;
  catalog: string;
}

export declare const LiveConnectionWizard: React.ComponentType<LiveConnectionWizardProps>;
