LiveConnectionWizard from tessallite-excel-plugin. Use via `window.TessalliteExcel.LiveConnectionWizard` (bundle loaded from the root `_ds_bundle.js`). Wrap the tree in `<TaskPaneProvider>` (full provider chain in README.md — components read theme/i18n from that context).

## Props

```ts
interface LiveConnectionWizardProps {
  open: boolean;
  onClose: () => void;
  serverUrl: string;
  catalog: string;
}
```
